from django.contrib import admin
from assapp.models import *
# Register your models here.


admin.site.register(user_details)

admin.site.register(Quations)



