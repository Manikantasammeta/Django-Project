from django.urls import path
from django import urls
from assapp import views


urlpatterns = [
    
    path("",views.index,name="index"),
    path("index2",views.index2,name="index2"),
    path("login/",views.log_in,name="login"),
    path("reg/",views.reg,name="reg"),
    path("quiz/",views.quiz,name="quiz"),
    path("mat",views.mat,name="mat"),
    path("last/",views.last,name="last"),
    path("user_profil",views.profil,name="profil"),
    path("logout",views.user_log_out,name="logout"),
    path("Quiz_list",views.lists,name="qlist"),
     
    
    ]