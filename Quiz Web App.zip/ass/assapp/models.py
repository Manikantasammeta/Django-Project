from django.db import models
from django.contrib.auth.models import User




# Create your models here.

class user_details(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    ph =models.IntegerField()
    age =models.IntegerField()
    user_img = models.ImageField(upload_to="user_img/",blank=True)
    
    
    def __str__(self):
        return self.user.username
    
    
    
class Quations(models.Model):
    Type = models.CharField(max_length=10)
    Quation = models.TextField(max_length=500)
    option_1 =models.CharField(max_length=100)
    option_2 =models.CharField(max_length=100)
    option_3 =models.CharField(max_length=100)
    option_4 =models.CharField(max_length=100)
    Answer =models.CharField(max_length=100)
    
    
    def __str__(self):
        return (self.Quation)
    
