from django.shortcuts import render
from assapp.forms import user__form,user__profile__form
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth import authenticate,login,logout
from .models  import *
import random as rm

# Create your views here.
def index(request):
    if request.method == 'POST':
        print(request.POST)
        return HttpResponseRedirect(reverse("index2"))
        
    return render(request,"index.html")




def mat(request):
   return  render(request,"materials.html")


def lists(request):
    if request.method =="POST":
        p=request.POST
        p1=tuple(p)
        global r
        r=p1[-1]
        print(r)
        return HttpResponseRedirect(reverse("index2"))
    return render(request,"list.html")


def reg(request):
    
    regs =False
    if request.method =="POST":
        user_form = user__form(request.POST)
        profile_form = user__profile__form(request.POST,request.FILES)
        
        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()
            
            profile =profile_form.save(commit=False)         
            profile.user = user
              
            
            profile.save()
            regs=True
    else:
        user_form = user__form()
        profile_form = user__profile__form()
    return render(request,"reg.html",{"user_form":user_form,"profile_form":profile_form,"regs":regs})



def log_in(request):
    msg=True 
    if request.method =='POST':
        username = request.POST.get("username")
        password = request.POST.get("password")
        img =request.POST.get("user_img")
        user = authenticate(username=username,password=password)
        
        if user:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect(reverse('index'))
            else: 
                print("user is not in avtivate")
        else:
            pass
            msg=False
    return render(request,"login.html",{"msg":msg})


def quiz(request):
    de=user_details.objects.all
    quat = Quations.objects.all

    
    
    if request.method == 'POST':
        print(request.POST)
        ions=Quations.objects.all() 
        score=0
        wrong=0
        correct=0
        total=0
        amt=0
        
        for i in ions:
            if i.Type==r:
                total+=1
            if request.POST.get(i.Quation):
                amt+=1
                
            if i.Answer ==  request.POST.get(i.Quation):
                score+=10
                correct+=1
                
            else:
                 if i.Type==r:
                    wrong+=1 
        percent = score/(total*10) *100
        
        context = {
            'score':score,
            'time': request.POST.get('timer'),
            'correct':correct,
            'wrong':wrong,
            'percent':percent,
            'total':total,
            'amt':amt
            }
        
        return render(request,'last.html',context)
    
    context={"details":de,"Quation":quat ,'type':r}

    return render(request,"quiz.html",context)

def django_quations(request):
    return render(request)

def last(request):
    
    render(request,"last.html")
    

def user_log_out(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))

def profil(request):
    return render(request,"uprofil.html")

def index2(request):
    return render(request,"index2.html",{"type":r})